package xml;

/**
 * @author Daniel J. Rivers
 *         2014
 *
 * Created: Aug 19, 2014, 12:27:14 AM 
 */
public interface XMLValueModifier {
	
	public String modify( String value );

}
