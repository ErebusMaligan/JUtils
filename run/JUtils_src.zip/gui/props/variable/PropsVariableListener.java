package gui.props.variable;

/**
 * @author Daniel J. Rivers
 *         2013
 *
 * Created: Dec 3, 2013, 2:32:44 PM 
 */
@FunctionalInterface
public interface PropsVariableListener {

	public void valueChanged( PropsVariable var );
	
}
