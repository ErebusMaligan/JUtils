package gui.windowmanager;

/**
 * @author Daniel J. Rivers
 *         2015
 *
 * Created: Oct 15, 2015, 11:27:34 PM 
 */
public interface WindowClosedHook {
	public void closed();
}