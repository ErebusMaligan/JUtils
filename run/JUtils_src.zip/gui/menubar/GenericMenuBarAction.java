package gui.menubar;

/**
 * @author Daniel J. Rivers
 *         2013
 *
 * Created: Aug 28, 2013, 12:40:34 AM 
 */
public interface GenericMenuBarAction {

	public void execute( Object executor );
	
}
