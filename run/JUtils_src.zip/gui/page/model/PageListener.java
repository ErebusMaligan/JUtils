package gui.page.model;

/**
 * @author Daniel J. Rivers
 *         2015
 *
 * Created: May 30, 2015, 7:17:53 PM 
 */
@FunctionalInterface
public interface PageListener {
	public void pageSet( int p );
}